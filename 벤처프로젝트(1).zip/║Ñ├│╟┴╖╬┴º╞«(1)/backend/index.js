const express = require('express');
const { Pool } = require('pg');
const cors = require('cors'); // CORS 패키지 임포트
const app = express();
const port = 3001;

// PostgreSQL 연결 설정
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: '5432', // 실제 비밀번호로 대체
  port: 5432,
});

// CORS 미들웨어 사용
app.use(cors());

// JSON 요청 본문을 처리할 수 있도록 미들웨어 추가
app.use(express.json());

// 데이터 조회 예제
app.get('/api/vehicles', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM vehicle');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Database query failed' });
  }
});

// 서버 시작
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
