import React from 'react';

const AsideLeft = () => {
  return <div className="aside-left">Aside Left</div>;
  // 현준이 파트 = 추천 배너. 차량카드 4개정도 띄우고 배너 섹션 이쁘게 만들기!
  // 막히는 부분있으면 개인카톡!
};

export default AsideLeft;
