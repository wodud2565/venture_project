import React from 'react';

const AsideRight = () => {
  return <div className="aside-right">Aside Right</div>;
  //나중에 추가할 부분. 뭐하려고 했었지?  토론 끝나자마자 술마셔서 기억이 안나네.
};

export default AsideRight;
