import React from 'react';

const Header = () => {
  return <div className="header">Header</div>;
  // 도균이 파트 =네비게이션바 { 왼쪽에 홈버튼, 오른쪽에 3개( 로그인 로그아웃 찜목록 버튼)}
  // 막히는 부분있으면 개인카톡!
};

export default Header;
