import React from 'react';

const AsideRight = () => {
  return <div className="aside-right">Aside Right</div>;
};

export default AsideRight;
