import React from 'react';

const AsideLeft = () => {
  return <div className="aside-left">Aside Left</div>;
};

export default AsideLeft;
